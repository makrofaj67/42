/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rakman <rakman@student.42istanbul.com.tr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 15:15:21 by rakman            #+#    #+#             */
/*   Updated: 2024/10/14 15:37:04 by rakman           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *s, int c)
{
	size_t		i;

	i = 0;
	while ((s[i] != 0) || (s[i] != c))
	{
		i++;
	}
	if (s[i + 1] == c)
	{
		return (s + i);
	}
	else
	{
		return (NULL);
	}
}
