/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rakman <rakman@student.42istanbul.com.tr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 16:15:09 by rakman            #+#    #+#             */
/*   Updated: 2024/10/14 17:57:38 by rakman           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	size_t	i;
	size_t	j;
	char	*allocating;

	i = 0;
	j = ft_strlen(s) - start;
	allocating = (char *)malloc(sizeof(char) * len);
	if (allocating == NULL)
	{
		return (NULL);
	}
	else
	{
		while ((len >= 0) && (j >= 0))
		{
			allocating[i] = s[start];
			i++;
			start++;
		}
		return (allocating);
	}
}
