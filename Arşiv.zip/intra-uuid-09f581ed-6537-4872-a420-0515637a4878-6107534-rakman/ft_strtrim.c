/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rakman <rakman@student.42istanbul.com.tr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 18:08:16 by rakman            #+#    #+#             */
/*   Updated: 2024/10/14 19:34:47 by rakman           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strtrim(char const *s1, char const *set)
{
	int		i;
	int		j;
	int		k;
	char	*trimmed;

	i = 0;
	j = 0;
	trimmed = (char *)malloc(ft_strlen(s1) * sizeof(char));
	if (trimmed == NULL)
		return (NULL);
	while (s1[i])
	{	
		k = 0;
		while (set[j])
		{
			if (s1[i] == set[j])
				k = 1;
			j;
		}
		t
		i++;
	}
}
