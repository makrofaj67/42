/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rakman <rakman@student.42istanbul.com.tr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 14:41:41 by rakman            #+#    #+#             */
/*   Updated: 2024/10/14 14:52:12 by rakman           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcpy(char *restrict dst,
	const char *restrict src, size_t dstsize)
{
	size_t	i;

	i = 0;
	while ((dstsize - 1) && (ft_strlen(src) != 0))
	{
		dst[i] = src[i];
		i++;
		dstsize--;
	}
	if (dstsize != 0)
	{
		dst[i] = 0;
	}
	return (ft_strlen(src));
}
