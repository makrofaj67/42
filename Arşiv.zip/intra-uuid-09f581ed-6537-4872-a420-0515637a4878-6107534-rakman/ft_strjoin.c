/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rakman <rakman@student.42istanbul.com.tr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 17:58:02 by rakman            #+#    #+#             */
/*   Updated: 2024/10/14 18:48:30 by rakman           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	int		i;
	int		j;
	char	*newstring;

	i = 0;
	j = 0;
	newstring = (char *)malloc(sizeof(char) * (ft_strlen(s1) + ft_strlen(s2)));
	if (newstring == NULL)
		return (NULL);
	else
	{
		while (s1[i])
		{
			newstring[i] = s1[i];
			i++;
		}
		while (s2[j])
		{
			newstring[i] = s2[j];
			i++;
			j++;
		}
		return (newstring);
	}
}
