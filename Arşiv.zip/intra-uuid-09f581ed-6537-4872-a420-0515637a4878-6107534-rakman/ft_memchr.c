/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rakman <rakman@student.42istanbul.com.tr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 15:32:18 by rakman            #+#    #+#             */
/*   Updated: 2024/10/14 15:37:52 by rakman           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memchr(const void *s, int c, size_t n)
{
	size_t			i;
	unsigned char	*cc;

	i = 0;
	cc = unsigned char (c);
	while ((s[i] != 0) || (s[i] != cc))
	{
		i++;
	}
	if (s[i + 1] == cc)
	{
		return (s + i);
	}
	else
	{
		return (NULL);
	}
}
