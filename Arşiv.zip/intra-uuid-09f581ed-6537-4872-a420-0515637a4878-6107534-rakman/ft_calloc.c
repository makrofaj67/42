/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rakman <rakman@student.42istanbul.com.tr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 15:57:09 by rakman            #+#    #+#             */
/*   Updated: 2024/10/14 17:55:24 by rakman           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	*ft_calloc(size_t count, size_t size)
{
	void	*allocated;

	allocated = malloc(size * count);
	if (allocated == NULL)
	{
		return (NULL);
	}
	ft_memset(allocated, 0, size * count);
	return (allocated);
}
