/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rakman <rakman@student.42istanbul.com.tr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 15:20:28 by rakman            #+#    #+#             */
/*   Updated: 2024/10/14 15:24:50 by rakman           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *s, int c)
{
	size_t		i;

	i = ft_strlen(s);
	while ((s[i] != s[0]) || (s[i] != c))
	{
		i--;
	}
	if (s[i - 1] == c)
	{
		return (s - i);
	}
	else
	{
		return (NULL);
	}
}
