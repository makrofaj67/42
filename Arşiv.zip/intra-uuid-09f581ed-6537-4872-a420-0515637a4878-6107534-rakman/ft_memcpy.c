/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rakman <rakman@student.42istanbul.com.tr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/14 14:20:32 by rakman            #+#    #+#             */
/*   Updated: 2024/10/14 20:00:27 by rakman           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memcpy(void *restrict dst, const void *restrict src, size_t n)
{
	size_t						i;
	unsigned char	*restrict	dstpt;
	unsigned char	*restrict	srcpt;

	i = 0;
	dstpt = (unsigned char *restrict)dst;
	srcpt = (const unsigned char *restrict)src;
	while (n > 0)
	{
		dstpt[i] = srcpt[i];
		i++;
		n--;
	}
	return (dst);
}
